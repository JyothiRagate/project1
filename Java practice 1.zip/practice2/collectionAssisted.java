package practice2;
import java.util.*;

public class collectionAssisted {

	public static void main(String[] args) {
		System.out.println("ArrayList");
		ArrayList<String> city=new ArrayList<String>();   
	      city.add("Pune");//
	      city.add("Noida");    	   
	      System.out.println(city);  
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vec = new Vector<Integer>();
	      vec.addElement(17); 
	      vec.addElement(42); 
	      System.out.println(vec);
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("Preethi");  
	      names.add("Saranya");  	      
	      Iterator<String> itr=names.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	       System.out.println("\n");
	       System.out.println("HashSet");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(122);  
	       set.add(177);  
	       set.add(199);
	       set.add(128);
	       System.out.println(set);
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(10);  
	       set2.add(18);  
	       set2.add(16);
	       set2.add(13);	       
	       System.out.println(set2);
	      	} 
	      }  
	}

