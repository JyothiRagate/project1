package Practice;

public class Typecasting {
	public static void main(String[] args) {
		System.out.println("Implicit of the type casting");
		 char p='S';
		System.out.println("value of s:" +p);
		
		int a=p;
		System.out.println("value of a:" +a);
		
		float n='d';
		System.out.println("value of g:" +n);
		
		long r='n';
		System.out.println("value of r:" +r);
		
		double i='k';
		System.out.println("value of i:" +i);
		
		System.out.println("\n");
		
		System.out.println("Explicit type casting");
		double y=36.7;
		int z=(int)y;
		System.out.println("value of y:" +y);
		System.out.println("value of z:" +z);
		
	}

}

