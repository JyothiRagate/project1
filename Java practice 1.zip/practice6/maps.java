package practice6;
import java.util.*;
public class maps {


			public static void main(String[] args) {
				HashMap<Integer,String> hm=new HashMap<Integer,String>();      
			      hm.put(1,"Jyothi");    
			      hm.put(2,"Sagar");    
			      hm.put(3,"keerthi");   
			       
			      System.out.println("\nThe elements of Hashmap are ");  
			      for(Map.Entry <Integer,String> m:hm.entrySet()){ 
			       System.out.println(m.getKey()+" "+m.getValue());    
			      }
			     
			       
			      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
			      
			      ht.put(4,"Saranya");  
			      ht.put(5,"Meenu");  
			      ht.put(6,"Thriveni");  
			      ht.put(7,"Kavya");  

			      System.out.println("\nThe elements of HashTable are ");  
			      for(Map.Entry <Integer,String> n:ht.entrySet()){    
			       System.out.println(n.getKey()+" "+n.getValue());    
			      }
			      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
			      map.put(8,"Ramya");    
			      map.put(9,"Maha");    
			      map.put(10,"Swathi");       
			      
			      System.out.println("\nThe elements of TreeMap are ");  
			      for(Map.Entry <Integer,String> l:map.entrySet()){    
			       System.out.println(l.getKey()+" "+l.getValue());    
			      }    
			      
			   }  
		}