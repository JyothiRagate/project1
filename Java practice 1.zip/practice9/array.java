package practice9;
public class array {
public static void main(String[] args) {
int a[]= {100,200,300,400,500};
for(int i=0;i<5;i++) {
System.out.println("Elements of array a: "+a[i]);
}
int[][] b = {
            {9, 4, 7, 6}, 
            {5, 1,8 } };
      
      System.out.println("\nLength of row 1: " + b[0].length);
      }
}

