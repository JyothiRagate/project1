package practice3;
public class accessmodifier { 
  void display() 
     { 
         System.out.println("You are using defalut access specifier"); 
     } 
	public static void main(String[] args) {
		System.out.println("Dafault access Specifier");
		accessmodifier obj = new accessmodifier(); 		  
        obj.display(); 
	}
}
